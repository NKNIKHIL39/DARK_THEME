## New Theme?

We would love to support all code editors out there, but we need your help to accomplish that. Feel free to create a new theme based on our [color palette](https://github.com/dracula/dracula-theme#color-palette).

## Existing Theme?

Find the appropriate repository on the [Dracula organization](https://github.com/dracula). This is just the umbrella place where we store all themes.

And remember - consider fixing the issue yourself. That's the best way to contribute ;)